<?php
$server='localhost';
$foydalanuvchi='toor';
$parol='';
$mb_nomi='turar_joy';
$baza=new mysqli($server, $foydalanuvchi, $parol, $mb_nomi);
if ($baza->connect_error)
{
    die("bazaga boglanishda hatolik yuz berdi". $baza->connect_error);
}
?>

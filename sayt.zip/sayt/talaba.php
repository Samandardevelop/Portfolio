<?php
session_start();
include 'mb.php';
global $baza;
$joriy_katalog=getcwd();
$maxsus_katalog="/yangi/";
$talaba_idisi=$_POST['talaba_id'];
$ttj=$_POST['ttj'];
$bino=$_POST['bino'];
$tel=$_POST['tel'];
$rasm_nomi=$_FILES['rasm']['name'];
$rasm_turi=$_FILES['rasm']['type'];
$rasm_xatolik=$_FILES['rasm']['error'];
$rasm_xajmi=$_FILES['rasm']['size'];
$vaqtinchalik_joyi=$_FILES['rasm']['tmp_name'];

if (!empty($tel) and !empty($rasm_nomi))
{
    $sorov=mysqli_query($baza, "SELECT * FROM talabal WHERE talaba_id='$talaba_idisi'");
    $natija=mysqli_fetch_assoc($sorov);
    //fay yuklash.
    $ozgaruvchi=explode(".", $rasm_turi);
    $fayl_turi=strtolower(end($ozgaruvchi));
    $asl_fayl_nomi="19iom".".".$rasm_xajmi.".".$rasm_turi;
    $yuklash_yoli=$joriy_katalog.$maxsus_katalog.basename($asl_fayl_nomi);
    $yuklandi=move_uploaded_file($vaqtinchalik_joyi,$yuklash_yoli);
    if ($yuklandi==true and $talaba_idisi==$natija['talaba_id'] )
    {
        $natija=mysqli_query($baza, "UPDATE talabal SET ttj='$ttj', bino='$bino', tel='$tel', rasm='$asl_fayl_nomi', rasm_hajmi='$rasm_xajmi', rasm_turi='$fayl_turi'
            WHERE talaba_id='$talaba_idisi'");
        if ($natija==true)
        {
            $_SESSION['talabadan']="malumot kiritildi.";
            header("Location: kabinet.php");
        }
        else
        {
            $_SESSION['talabadan']="baza yangilanmadi.";
            header("Location: kabinet.php");
        }
    }
    else
    {
        $_SESSION['talabadan']="bunday id mavjud emas.";
        header("Location: kabinet.php");
    }
}
else
{
    $_SESSION['talabadan']="malumot kiritilmadi.";
    header("Location: kabinet.php");
}

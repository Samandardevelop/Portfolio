<?php
session_start();
include 'mb.php';
global $baza;

$talaba_idisi=$_POST['talaba_id'];
$ttj=$_POST['ttj'];
$bino=$_POST['bino'];
$tel=$_POST['tel'];
$rasm=$_POST['rasm'];

if (!empty($tel) and !empty($rasm))
{
    $sorov=mysqli_query($baza, "SELECT * FROM talabal WHERE talaba_id='$talaba_idisi'");
    $natija=mysqli_fetch_assoc($sorov);
    if ($talaba_idisi==$natija['talaba_id'])
    {
        $natija=mysqli_query($baza, "UPDATE talabal SET ttj='$ttj', bino='$bino', tel='$tel', rasm='$rasm'
            WHERE talaba_id='$talaba_idisi'");
        if ($natija==true)
        {
            $_SESSION['talabadan']="malumot kiritildi.";
            header("Location: ttj5.php");
        }
        else
        {
            $_SESSION['talabadan']="malumot kiritlmadi.";
            header("Location: ttj5.php");
        }
    }
    else
    {
        $_SESSION['talabadan']="bunday id mavjud emas.";
        header("Location: ttj5.php");
    }
}
else
{
    $_SESSION['talabadan']="malumot kiritilmadi.";
    header("Location: ttj5.php");
}

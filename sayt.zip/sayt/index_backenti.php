<?php
session_start();
include 'mb.php';
global $baza;

$login=$_POST['login'];
$parol=$_POST['parol'];
$kamendant=$_POST['kamendant'];

if (!empty($login) and !empty($parol))
{
    $parol1=hash('sha256', $parol);
    $sorov=mysqli_query($baza, "SELECT * FROM komendat WHERE login='$login' and parol='$parol1'");
    $natija=mysqli_fetch_array($sorov);
    if ($login==$natija['login'] and $parol1==$natija['parol'])
    {
        if ($kamendant==$natija['aktivligi'])
        {
            if ($natija['ttj']==1)
            {
                $_SESSION['kabinetga']=$natija['Id'];
                header("Location: kabinet.php");
            }
            if ($natija['ttj']==2)
            {
                $_SESSION['kabinetga']=$natija['Id'];
                header("Location: ttj2.php");
            }
            if ($natija['ttj']==3)
            {
                $_SESSION['kabinetga']=$natija['Id'];
                header("Location: ttj3.php");
            }
            if ($natija['ttj']==4)
            {
                $_SESSION['kabinetga']=$natija['Id'];
                header("Location: ttj4.php");
            }
            if ($natija['ttj']==5)
            {
                $_SESSION['kabinetga']=$natija['Id'];
                header("Location: ttj5.php");
            }
        }
        else
        {
            $_SESSION['indexga']="siz blok holatdasiz kira olmaysiz";
            header("Location: index.php");
        }
    }
    else
    {
        $_SESSION['indexga']="Siz kamendent emasiz begonalarga kirish taqiqlanadi.";
        header("Location: index.php");
    }
}
else
{
    $_SESSION['indexga']="bosh maydonlar mavjud";
    header("Location: index.php");
}
?>
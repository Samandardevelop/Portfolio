<style>

    body{
        width: 100%;
        margin: 0;
        padding: 0;
    }
    a{
        color: red !important;
    }
    .head{
        background-image: url("rasml/internet-das-coisas.jpg");
    }
    .container{
        width: 100%;
    }
    .button{
        position: absolute;
        top: 2rem;
        right: 4rem;
        padding: 0.3rem 1.4rem;
        border-radius: 7px;
        border: none;
        background-color: red;
        color: #fff;
    }
    .button:hover{
        background-image: linear-gradient(90deg, #c00bc6, #8c0ce7, #da16e7);
        border-radius: 10px;
        /*padding: 0.4rem 1.6rem;*/
        font-size: 18px;
        padding: 0.1rem 1.1rem;
    }
    select{
       position: absolute;
        left: 1rem;
        /*top: 2rem;*/
    }
    .form{
        position: relative;
        width: 100%;
        background-color: #0dcaf0;
    }

    h1{
        text-align: center;
        color: white;
    }
    p{
        color: white;
        text-align: center;
        font-size: 20px;
        margin: 0;
        padding: 0;
    }
    .row{
        display: flex;
        height: 800px;
    }
    .col-3 {
        width: 20%;
        background-color: black;
        height: 90%;
    }
    .bolim{
        width: 80%;
    }
    .qator1{
        position: relative;
        background-color: #06cf04;
        padding: 10px;
        text-align: center;
        justify-content: space-between;
    }

    .qator2{
        margin: 0 auto;

    }
    a{
        text-decoration: none;
        color: white;
        font-size: 20px;
    }
    .col-3 ul li{
        margin-bottom: 25px;
    }
</style>